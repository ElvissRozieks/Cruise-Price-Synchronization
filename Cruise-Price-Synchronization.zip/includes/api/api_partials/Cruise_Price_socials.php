<?php

namespace cruise\includes\api\api_partials;

/**
 * Fired during plugin activation.
 *
 * This class defines all code necessary to run during the plugin's activation.
 *
 * @since      1.0.0
 * @package    Cruise_Price
 * @subpackage Cruise_Price/includes
 */
class Cruise_Price_socials {

    public function __construct() {
        $this->board_token = $board_token;

    }

    public function render() {

    }
  
}
